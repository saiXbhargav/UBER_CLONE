import React from 'react';
import './index.css'

function App() {
  return (
    <div className="bg-gray-100 text-gray-800 min-h-screen font-sans">
      {/* Navbar */}
      <header className="bg-white shadow sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">MyBrand</h1>
          <nav className="space-x-6">
            <a href="#" className="text-gray-600 hover:text-blue-600">Home</a>
            <a href="#" className="text-gray-600 hover:text-blue-600">Features</a>
            <a href="#" className="text-gray-600 hover:text-blue-600">Pricing</a>
            <a href="#" className="text-gray-600 hover:text-blue-600">Contact</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-4xl sm:text-5xl font-extrabold mb-6">Build Beautiful Interfaces with Tailwind</h2>
          <p className="text-lg mb-8">Create responsive, modern UIs quickly and easily with utility-first CSS.</p>
          <button className="bg-white text-blue-600 font-semibold px-6 py-3 rounded-lg shadow hover:bg-blue-100 transition">
            Get Started
          </button>
        </div>
      </section>
      {/* No additional code needed here for Tailwind to work.
        Make sure Tailwind CSS is installed and configured in your project. */}
      {/* Features */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <h3 className="text-3xl font-bold text-center mb-12">Our Features</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow p-6 hover:shadow-lg transition">
              <h4 className="text-xl font-semibold mb-2">🚀 Fast Development</h4>
              <p>Speed up your workflow with Tailwind’s powerful utility classes.</p>
            </div>
            <div className="bg-white rounded-xl shadow p-6 hover:shadow-lg transition">
              <h4 className="text-xl font-semibold mb-2">🎨 Customizable Design</h4>
              <p>Fully themeable and easy to extend for custom design systems.</p>
            </div>
            <div className="bg-white rounded-xl shadow p-6 hover:shadow-lg transition">
              <h4 className="text-xl font-semibold mb-2">📱 Responsive by Default</h4>
              <p>Mobile-first utilities make your site responsive without extra code.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t py-6 mt-10 text-center text-gray-500 text-sm">
        © 2025 MyBrand. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
